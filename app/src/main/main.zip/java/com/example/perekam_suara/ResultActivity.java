package com.example.perekam_suara;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ResultActivity extends AppCompatActivity implements RVA.ItemClickListener {

    public ArrayList<SongList> song_data = new ArrayList();
    public ArrayList<SongList> picked_song = new ArrayList();
    RVA adapter;
    private Button play;

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        Bundle extras = getIntent().getExtras();
        String output_location = getFilesDir() + "/audio.wav";
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        int[] colors = {Color.parseColor("#fcd092"),
                Color.parseColor("#f59c20")};
        LinearLayout rl = findViewById(R.id.rl);
        GradientDrawable gradientDrawable = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                colors

        );
        gradientDrawable.setCornerRadius(0f);
        rl.setBackground(gradientDrawable);

        String[] song = {"Jika", "Maafkan Aku", "Beharap tak berpisah", "Cinta Membawamu Kembali", "Pupus"};
        String[] artis = {"Melly goeslau", "Tiara", "Reza", "Dewa 19", "Dewa 19"};
        int[] img = {R.drawable.jika, R.drawable.maafkan, R.drawable.btb, R.drawable.ckm, R.drawable.jika};

        if (extras != null) {
            double[] value = (double[]) getIntent().getSerializableExtra("Result");

            for (int n = 0; n < value.length; n++) {
                song_data.add(new SongList(song[n], artis[n], ContextCompat.getDrawable(this, img[n]), value[n]));
            }

            //The key argument here must match that used in the other activity
        }

        // set up the RecyclerView
        RecyclerView recyclerView = findViewById(R.id.rvAnimals);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RVA(this, song_data);
        adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);
        play = (Button) findViewById(R.id.play);

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MediaPlayer mediaPlayer = new MediaPlayer();
                try {
                    mediaPlayer.setDataSource(output_location);
                    mediaPlayer.prepare();
                    mediaPlayer.start();
                    Toast.makeText(getApplicationContext(), "Playing Audio", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    // make something
                }
            }
        });

    }

    @Override
    public void onItemClick(View view, int position) {
//        Toast.makeText(this, "You clicked " + adapter.getItem(position) + " on row number " + position, Toast.LENGTH_SHORT).show();
    }
}